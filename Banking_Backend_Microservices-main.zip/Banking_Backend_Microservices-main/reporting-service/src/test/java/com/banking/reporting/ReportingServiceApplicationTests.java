package com.banking.reporting;


class ReportingServiceApplicationTests {

	void contextLoads() {
	}

}
