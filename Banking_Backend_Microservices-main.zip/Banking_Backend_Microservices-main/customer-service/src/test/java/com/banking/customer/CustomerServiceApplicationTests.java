package com.banking.customer;


class CustomerServiceApplicationTests {

	void contextLoads() {
	}

}
