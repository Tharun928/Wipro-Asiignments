# Banking_Backend_Microservices
Microservices Architecture: Designed and implemented a scalable microservices-based banking system using Spring Boot 3.4.4 and Java 21, including API Gateway, Customer, Account, Transaction, Payment, Audit, Notification, and Reporting services.
