package com.banking.auth;




class AuthServiceApplicationTests {

	void contextLoads() {
	}

}
