package com.banking.payment;


class PaymentServiceApplicationTests {


	void contextLoads() {
	}

}
