package com.banking.notification;


class NotificationServiceApplicationTests {


	void contextLoads() {
	}

}
