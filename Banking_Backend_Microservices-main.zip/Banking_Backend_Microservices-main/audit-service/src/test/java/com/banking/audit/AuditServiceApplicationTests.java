package com.banking.audit;


class AuditServiceApplicationTests {


	void contextLoads() {
	}

}
