package com.banking.transaction;


class TransactionServiceApplicationTests {

	
	void contextLoads() {
	}

}
